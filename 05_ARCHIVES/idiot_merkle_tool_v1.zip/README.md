# IDIOT — MerkleDistributor Tool (Base)

This is a plug‑and‑play Hardhat project to generate a Merkle tree from your allowlist CSV, deploy a distributor, and set the root/times.

## Requirements
- Node 18+
- `npm i`
- Copy `.env.example` → `.env` and fill `RPC_URL` and `PRIVATE_KEY` (Base mainnet or testnet).

## Files you care about
- `contracts/MerkleDistributor.sol` — claim contract
- `scripts/gen-manifest.js` — CSV → JSON manifest (with proofs)
- `scripts/check-proof.js` — sanity check one address against the JSON
- `scripts/deploy.js` — deploy distributor
- `scripts/set-root.js` — set merkle root & claim window
- `templates/allowlist.csv` — put your allowlist here (address,amount,pool,notes,...) in **whole tokens**
- `airdrop/idiocracy-1.json` — generated manifest for the website + proofs for on‑chain claims

## Quickstart

1) Install
```bash
npm install
cp .env.example .env
# fill RPC_URL + PRIVATE_KEY
```

2) Put your allowlist
```
templates/allowlist.csv
address,amount,pool,notes
0xabc...,25000,community,Discord OG
...
```

3) Generate manifest + proofs
```bash
npm run gen:manifest
# writes airdrop/idiocracy-1.json and prints the Merkle root
```

4) Deploy distributor
```bash
npm run build
npm run deploy
# copy the address it prints
```

5) Set root + window
```bash
# use the root printed in step 3 and your dates (unix seconds)
npm run set:root
```

6) Upload the JSON to your site
- Put `airdrop/idiocracy-1.json` at `/public_html/airdrop/idiocracy-1.json`
- Your claim UI can now show eligibility and pass proofs to the contract

**Note:** Manifest contains both `amount` (human tokens string) and `amountWei` (uint256 string) so UI and on‑chain agree.

