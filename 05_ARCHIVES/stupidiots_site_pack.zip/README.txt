STUPIDIOTS ONE-PAGE SITE — ASSET PACK
=====================================
Paths (upload exactly as-is):
/public_html/index.html
/public_html/assets/img/logo.svg
/public_html/assets/img/coin-3d.png
/public_html/assets/img/social-facebook.svg
/public_html/assets/img/social-x.svg
/public_html/assets/img/social-discord.svg

Notes:
- The HTML expects these exact paths.
- Replace CONTRACT_ADDRESS in index.html once and it updates everywhere.
- Update the DexScreener iframe src and 'Open Chart' link when you have the pair/token URL.
- The social icons here are neutral placeholders (letters), not trademark artwork.
