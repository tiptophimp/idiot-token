# Legacy Docs (Imported)
- Read-only imports from the previous site.
- If any doc mentions contract/tokenomics, treat it as historical; homepage is the single source of truth.

## Contents
- Tutorials: metamask-setup.html, how-to-buy-on-base.html, complete-buying-guide.html, sending-receiving-guide.html

## Owner
- OPS-SAFE (content ops), reviewed by TR-SAFE for compliance.
