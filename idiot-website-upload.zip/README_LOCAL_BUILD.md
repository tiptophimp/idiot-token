# IDIOT — Local Build Notes
- Source of truth for critical data: index.html + 03_DOCUMENTS/website-copy-freeze.md
- NEVER edit live server; deploy via release ZIPs.

## Latest Actions
- Imported legacy guides/memes into /docs/legacy/ and /assets/legacy/
- Added Learn hub at /learn.html and menu link in navbar
- Footer wired to PDFs + top tutorials
- Humor strip added (small, muted)

## Next Steps
1) Replace "Pending" placeholders with real LP locker URL and Sablier stream links
2) Run full QA (addresses, links, tokenomics sync)
3) Package: staging + production ZIP (same artifact), update manifest & release notes
