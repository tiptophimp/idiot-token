# Legacy Pages (Archive)
- Legacy HTML pages kept for reference.
- If a legacy page conflicts with current truth, a banner warns:
  "Outdated: see homepage for current data."
