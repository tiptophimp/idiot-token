# Legacy Assets (Memes/Images)
- Filenames normalized (lowercase, hyphens).
- Alt text: humorous but respectful; no price promises.

## Update Rules
- Add new memes here; reference them from /learn.html
- Optimize images before packaging if possible.
